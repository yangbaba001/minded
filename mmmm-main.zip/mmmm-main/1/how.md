i need a antibot.js thats will connected to my server.js

the antibot should d this

Bot filtration
VPN/Proxy Filtration
Geo Database
Realtime Clicks stastics

the admin.js we dont all this 

timestamp: new Date(Date.now() - 5000).toISOString(),
            status: 'ALLOWED',
            reason: 'Legitimate visitor',
            ip: '197.210.85.23',
            country: 'NG',
            countryName: 'Nigeria',
            city: 'Lagos',
            org: 'MTN Nigeria',
            isp: 'MTN Nigeria',
            ipType: 'Residential',
            isBot: false,
            userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' is fake 

            we need real databse if the anyone clik it either bot or any track it with antibot.js for security first 
            if it bot should bloked or vpn/proxy should be bloked if it real user should access and immediatly should be saved database and should be updated on the admin page too

            antibot should alayws check any click alwys